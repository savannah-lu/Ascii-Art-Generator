using System;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Linq;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Text;


/*THE SITUATION: The art is converted all nice and properly in its string form. But when I send the text to the textbox,
 * 
 *   it gets messed up. I saw somewhere in that article they did something to "preserve" its form. If that doesn't work, I may
 *   have to resize the textbox. Next work on kernel form.
 *  
 * 
 */


namespace AsciiArtConverter
{
    public partial class Form1 : Form
    {  
        public Form1()
        {
            InitializeComponent();
        }

        public int value1;
        public int value2;

        public void button1_Click(object sender, EventArgs e)
        {
            

            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;

                    pictureBox1.Image = new Bitmap(openFileDialog1.FileName);
                    
                    Bitmap b = new Bitmap(openFileDialog1.FileName);

                    
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    
                }
            }
        }

        public void button2_Click(object sender, EventArgs e)
        {
            decimal value1 = numericUpDown1.Value;
            decimal value2 = numericUpDown2.Value;
          

            if(pictureBox1.Image == null)
            {
                MessageBox.Show("Please select an image!", "Bruh", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(numericUpDown1.Value == 0 || numericUpDown2.Value == 0)
            {
                MessageBox.Show("Please select a kernel size.");
            }
            else
            {
                Bitmap b = new Bitmap(pictureBox1.Image);

                decimal scale = b.Width / b.Height;

                b = ResizeImage(b, 500, 500);

                pictureBox1.Image = b;

                BitmapAscii bitmapAscii = new BitmapAscii();

                string str = "";



                //str = bitmapAscii.ToString(b, (int)numericUpDown1.Value, (int)numericUpDown2.Value);


                //textBox1.Text = "Chars\t\tNumbers\n";

                //for(int i = 0; i < bitmapAscii.asciiChars.Count; i++)
                //{
                //   textBox1.AppendText(bitmapAscii.asciiChars[i]);
                //   textBox1.AppendText(bitmapAscii.normalizedNums[i].ToString() + "\t\t");
                //}

                 
                str = bitmapAscii.Asciitize(b, (int)numericUpDown1.Value, (int)numericUpDown2.Value);

                richTextBox1.Text = str;




            }

            /// <summary>
            /// Resize the image to the specified width and height.
            /// </summary>
            /// <param name="image">The image to resize.</param>
            /// <param name="width">The width to resize to.</param>
            /// <param name="height">The height to resize to.</param>
            /// <returns>The resized image.</returns>
            static Bitmap ResizeImage(Image image, int width, int height)
            {
                var destRect = new Rectangle(0, 0, width, height);
                var destImage = new Bitmap(width, height);

                destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

                using (var graphics = Graphics.FromImage(destImage))
                {
                    graphics.CompositingMode = CompositingMode.SourceCopy;
                    graphics.CompositingQuality = CompositingQuality.HighQuality;
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    graphics.SmoothingMode = SmoothingMode.HighQuality;
                    graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                    using (var wrapMode = new ImageAttributes())
                    {
                        wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                        graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                    }
                }

                return destImage;
            }


            static Bitmap GetReSizedImage(Bitmap inputBitmap, int asciiWidth)
            {
                int asciiHeight = 0;
                //Calculate the new Height of the image from its width
                asciiHeight = (int)Math.Ceiling((double)inputBitmap.Height * asciiWidth / inputBitmap.Width);

                //Create a new Bitmap and define its resolution
                Bitmap result = new Bitmap(asciiWidth, asciiHeight);
                Graphics g = Graphics.FromImage((Image)result);


                //The interpolation mode produces high quality images
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                g.DrawImage(inputBitmap, 0, 0, asciiWidth, asciiHeight);
                g.Dispose();
                return result;
            }

            static string ConvertToAscii(Bitmap image)
            {

                string[] _AsciiChars = new string[] { "#", "#", "@", "%", "=", "+", "*", ":", "-", ".", " " };

                Boolean toggle = false;
                StringBuilder sb = new StringBuilder();


                for (int h = 0; h < image.Height; h++)
                {
                    for (int w = 0; w < image.Width; w++)
                    {
                        Color pixelColor = image.GetPixel(w, h);


                        //Average out the RGB components to find the Gray Color
                        int red = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                        int green = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                        int blue = (pixelColor.R + pixelColor.G + pixelColor.B) / 3;
                        Color grayColor = Color.FromArgb(red, green, blue);


                        //Use the toggle flag to minimize height-wise stretch
                        if (!toggle)
                        {
                            int index = (grayColor.R * 10) / 255;
                            sb.Append(_AsciiChars[index]);
                        }
                    }
                    if (!toggle)
                    {
                        sb.Append("\n");
                        toggle = true;
                    }
                    else
                    {
                        toggle = false;
                    }
                }


                return sb.ToString();
            }


         
        }

       
    }


    public class BitmapAscii
    {

        public List <string> asciiChars = new List<string>();
        public List <double> normalizedNums = new List<double>();

        public string Asciitize(Bitmap b, int width, int height)
        {
            if (width == 1 && height == 1)
            {
                bool toggle = false;
                double pixColor = 0;
                string ascii = "";
                StringBuilder sb = new StringBuilder();
                Color c = new Color();

                //use nested loops to traverse through each pixel
                for (int i = 0; i < b.Height; i++)
                {
                    for (int j = 0; j < b.Width; j++)
                    {
                        c = b.GetPixel(j, i);             //get pixel
                        pixColor = AveragePixel(c);      //get grayscale (normalized) value
                        ascii = GrayToString(pixColor); //get ascii char based on grayscale value


                        //if (!toggle)
                        //{
                            sb.Append(ascii);
                        //}

                        if (i > 23 && i < 25 && j > 300 && j < 400)
                        {
                            asciiChars.Add(ascii);
                            normalizedNums.Add(pixColor);
                        }

                    }

                    //if (!toggle)
                    //{
                        sb.Append("\r\n");
                        toggle = true;
                    //}
                    //else
                    //{
                    //    toggle = false;
                    //}
                }

                return sb.ToString();
            }
            else
            {
                Color c = new Color();
                double pixColor = 0;
                string ascii = "";
                StringBuilder sb = new StringBuilder();
                List<Color> colors = new List<Color>();
                int moveW = 0;
                int moveH = 0;
                double moves = b.Width / width;
                int rows = 0;

                //These two are the ones continuously going up. MoveW and H are converting back to whatever spot they need to be at when the loop reiterates
                int w = moveW;
                int h = moveH;


                for (int i = 0; i < moves; i++)
                {
                    for (int j = 0; j < width; j++)
                    {

                        for (int k = 0; k < height; k++)
                        {
                            c = b.GetPixel(moveW, moveH);
                            colors.Add(c);
                            moveW++;
                        }

                        moveH++;
                        moveW = w;

                        //once all kernels have been collected, move width over amount needed
                        if (j == width - 1)
                        {
                            w += width;
                            moveH = h; //reset height 
                        }
                    }

                    pixColor = AverageColor(colors);
                    ascii = GrayToString(pixColor);
                    sb.Append(ascii);
                    colors.Clear();



                    if (i == moves - width && rows < (moves - width)) //if we're at the end of the row
                    {
                        h += height; //move the height downward
                        moveH = h;
                        moveW = 0;
                        w = 0;   //reset width to start at the beginning of the next row
                        i = 0;  //reset for loop
                        sb.Append("\r\n");
                        rows++;
                    }

                }



                return sb.ToString();
            }
        }
      

        //method that accepts three int values(presumably RBG values) and returns a grayscale value
        public double AveragePixel(int r, int b, int g)
        {
            //average out RGB values to find the grayscale value
            int red = (r + b + g) / 3;
            int green = (r + b + g) / 3;
            int blue = (r + b + g) / 3;

            Color c = Color.FromArgb(red, green, blue);

            double avg = (double)c.R / 255;
            return avg;
        }

        //OVERLOADED METHOD: accepts a Color value instead of three ints
        public double AveragePixel(Color c)
        {
            double avg = (c.R + c.G + c.B) / 3;

            //int red = (c.R + c.G + c.B) / 3;
            //int green = (c.R + c.G + c.B) / 3;
            //int blue = (c.R + c.G + c.B) / 3;

            //Color co = Color.FromArgb(red, green, blue);

            avg = avg / 255;

            return avg;
        }

        //create method that accepts a List of color values and returns an average normalized value (double)
        public double AverageColor(List <Color> colors)
        {
            double avg = 0;

            //loop through list of colors and get each normalized value
            for(int i = 0; i < colors.Count; i++)
            {
                int red = (colors[i].R + colors[i].G + colors[i].B) / 3;
                int green = (colors[i].R + colors[i].G + colors[i].B) / 3;
                int blue = (colors[i].R + colors[i].G + colors[i].B) / 3;

                Color c = Color.FromArgb(red, green, blue);

                //store normalized value in var
                avg += (double)c.R / 255;
            }

            //find average normalized value
            avg = avg / colors.Count;

            return avg;
        }

        // " .:-=+*#%@"

        //{ "#", "#", "@", "%", "=", "+", "*", ":", "-", ".", " " };

        //create method that accepts a normalized value and returns a string containing an ascii character
        public string GrayToString(double d)
        {
            //round number down for optimal results 
            d = Math.Round(d, 2);
            string str = "";

            if(d >= 0.0 && d <= 0.10)
            {
                str = "@";
            }
            else if (d >= 0.11 && d <= 0.20)
            {
                str = "%";
            }
            else if (d >= 0.21 && d <= 0.30)
            {
                str = "#";
            }
            else if (d >= 0.31 && d <= 0.40)
            {
                str = "*";
            }
            else if (d >= 0.41 && d <= 0.50)
            {
                str = "+";
            }
            else if (d >= 0.51 && d <= 0.60)
            {
                str = "=";
            }
            else if (d >= 0.61 && d <= 0.70)
            {
                str = "-";
            }
            else if (d >= 0.71 && d <= 0.80)
            {
                str = ":";
            }
            else if (d >= 0.81 && d <= 0.90)
            {
                str = ".";
            }
            else if (d >= 0.91 && d <= 1)
            {
                str = " ";
            }
            else
            {
                str = "?";
            }

            return str;
        }
    }
}